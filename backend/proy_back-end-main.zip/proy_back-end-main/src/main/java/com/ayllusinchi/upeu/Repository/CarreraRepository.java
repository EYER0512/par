package com.ayllusinchi.upeu.Repository;

import com.ayllusinchi.upeu.entidades.Carrera;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author etham
 */
public interface CarreraRepository extends CrudRepository<Carrera, Long>{
    
}
