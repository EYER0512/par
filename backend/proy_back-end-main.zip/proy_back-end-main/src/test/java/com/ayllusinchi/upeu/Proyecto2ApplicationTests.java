package com.ayllusinchi.upeu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
